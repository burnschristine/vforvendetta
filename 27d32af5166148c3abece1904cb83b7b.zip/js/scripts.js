console.log('Be like Browser.');
// Lettering
$('h1').lettering();

// Video Player
$('video').mediaelementplayer();